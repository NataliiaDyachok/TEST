const data = require('../../data.json');
const formatter = require('./helper3');

module.exports = (sourceProducts) => {};
